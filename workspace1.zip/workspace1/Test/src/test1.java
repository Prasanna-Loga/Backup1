import java.util.ArrayList;
import java.util.List;

public class test1 {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		List list=new ArrayList();
		list.add("one");
		list.add("two");
		list.forEach(num->System.out.println(num));
	}
}
