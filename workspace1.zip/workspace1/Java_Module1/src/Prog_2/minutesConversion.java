package Prog_2;

public class minutesConversion {
	public void convert(int minute){
		System.out.println(minute/(365*24*60)+" years and "+(minute%(365*24*60))/(24*60)+" days");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new minutesConversion().convert(599040);
	}

}
