/*
 * 6.	Write a java class to calculate your experience (no.of years, no.of months &no.of days) in Wipro by using java time API.
 */

package Prog_6;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class DateDifference {
	public static void main(String[] args) {
	LocalDate date = LocalDate.now();
	
	LocalDate date1 = LocalDate.of(2017,Month.MARCH,31);
	Period diff=Period.between(date1, date);
	System.out.println("Experiance in Wipro is "+diff.getYears()+" years "+diff.getMonths()+" months "+diff.getDays()+" days");
	}
}
