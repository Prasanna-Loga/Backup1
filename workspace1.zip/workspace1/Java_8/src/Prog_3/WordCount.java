package Prog_3;
@FunctionalInterface
public interface WordCount {
	int Count(String str);

}
