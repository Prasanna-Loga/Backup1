/*
 * 4.	Add following Ideas to Assignment 1

i.	Along with getters & setters add a static method static int compareBySal(Employee e1,Employee e2) to compare employee 
ii.	Use Collections.sort (-,-) method to compare employee objects of Array List.
iii.	Invoke compareBySal() method by using Method Reference and pass it as second argument to the sort() method.

 */

package Prog_4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class EmployeeArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> empList=new ArrayList<Employee>();
		for(int i=0;i<5;i++){
			Employee emp=new Employee();
			emp.setID("iD"+i);
			emp.setName("Employee"+i);
			emp.setAddress("Address"+i);
			emp.setSalary((int) ((Math.random() * 900000) + 100000) / 10.0);
			empList.add(emp);
		}
		System.out.println("-----------Employee List----------------");
		System.out.println("Employee_ID\tEmployee_Name\tEmployee_Address\tSalary");
		empList.forEach(list->System.out.println(list.getID()+"\t\t"+list.getName()+"\t"+list.getAddress()+"\t\t"+list.getSalary()));
	
		System.out.println("----------Employee sorted list with salary---------");
		
		Collections.sort(empList,Employee::compareBySal);
		System.out.println("Employee_ID\tEmployee_Name\tEmployee_Address\tSalary");
		empList.forEach(list->System.out.println(list.getID()+"\t\t"+list.getName()+"\t"+list.getAddress()+"\t\t"+list.getSalary()));
	
	}

}
