/*
 * 5.	Write a java class to find the date of next month second Sunday by using java time API.
 */

package Prog_5;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class timeApi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate date = LocalDate.now().plusMonths(1).withDayOfMonth(1).with(DayOfWeek.SUNDAY).plusDays(7);  
		System.out.println("Secound sunday date of next month is : "+date);
	
		}

}
