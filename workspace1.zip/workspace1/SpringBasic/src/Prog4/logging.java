package Prog4;

import java.util.Date;
import java.util.Timer;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class logging {
	//@Around("execution(* *(..)) && @annotation(Loggable)")
/*	@Pointcut("execution(* *Prog4.*(..))")
	   private void selectAll(){}*/
	Date start,end;
	@Before("execution(* Prog4.Main4.get*(..))")
	   public void beforeAdvice(){
	      start=new java.util.Date();
	      //System.out.println(start);
	   }
	@After("execution(* Prog4.Main4.get*(..))")
	   public void afterAdvice(){
		
	   }

	   /** 
	      * This is the method which I would like to execute
	      * when any method returns.
	   */
	   @AfterReturning("execution(* Prog4.Main4.get*(..))")
	   public void afterReturningAdvice(JoinPoint jp){
		   end=new java.util.Date();
		      System.out.println(jp.getSignature().getName()+" invoked at "+end);
		      System.out.println("The total time taken by each of these methods for their execution "+(end.getTime()-start.getTime())+"ms");
	   }

}
