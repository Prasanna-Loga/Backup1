/*1.	Create a java application that creates class called SortedDirList with a constructor 
 * that takes a File object and builds a sorted directory list from the files at that File. 
 * Add to this class two overloaded list () methods: 
 * the first produces the whole list, and the second produces the subset of the list that matches its argument (which is a regular expression).*/
package com.a.sorteddirlist;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class sortedDirList {

	public sortedDirList(File file){
		
		try(Stream<Path> stream = Files.list(Paths.get(file.getPath()))) {
			stream.filter(Files::isDirectory).map(Path::getFileName).sorted().forEach(System.out::println);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	
	public List<String> list(File file){
		List<String> fileList=new ArrayList<String>();
		try (Stream<Path> stream = Files.list(Paths.get(file.getPath()))){
			fileList=stream.filter(Files::isDirectory).map(Path::getFileName).map(P->"Directory\t"+P.toString()).collect(Collectors.toList());
				}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (Stream<Path> stream = Files.list(Paths.get(file.getPath()))){
			fileList.addAll(stream.filter(Files::isRegularFile).map(Path::getFileName).map(P->"File\t"+P.toString()).collect(Collectors.toList()));
			}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return fileList;	
	}
	public void list(File file,String fileName){
		
		try (Stream<Path> stream = Files.list(Paths.get(file.getPath(),fileName))){
			 if(stream.count()!=0)
			list(new File(file+"\\"+fileName)).forEach(System.out::println);
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file1 = new File("C:\\users\\"+"PR377171\\Downloads");
		System.out.println("\n--------------------Sorted Directory List--------------------\n");
		sortedDirList sorteddirlist = null;
			sorteddirlist = new sortedDirList(file1);
		System.out.println("\n--------------------Full List------------------------------\n");
		
		sorteddirlist.list(file1).forEach(System.out::println);
		String searchFile="Office";    //file name from that directory
		System.out.println("\n---------------------Sub-list of "+searchFile+" ----------------------------\n");
		sorteddirlist.list(file1,searchFile);
	}

           
}