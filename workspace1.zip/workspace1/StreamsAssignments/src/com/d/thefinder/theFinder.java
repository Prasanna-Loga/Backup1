/*
 * 4.	Write a java application that read the input file, line by line, 
 * and count the occurrences of the word �the� in each line.
 */
package com.d.thefinder;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

public class theFinder {

	public long finder(File file) {

		long theCount=0;
		try(BufferedReader readLine=Files.newBufferedReader(Paths.get(file.getPath()),Charset.defaultCharset())) {
			
			theCount=readLine.lines().flatMap(line->Arrays.stream(line.split("\\s+"))).filter(word->word.equals("the")).count();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return theCount;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\Users\\PR377171\\workspace1\\StreamsAssignments\\test1.txt");
		System.out.println("-------------Frequency of the occurrance of 'the' of the given text file-----------");
		System.out.println(new theFinder().finder(file));
	}

	

}
