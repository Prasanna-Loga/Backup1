package Prog4_Interface.music;

public interface Playable {
	void play();
}
