/*2.	There is an animal class which has the common characteristics of all animals. 
 * 		Dog, Horse, Cat are animals(sub-class). Each can shout, but each shout is different. 
 * 		Use polymorphism to create objects of same and using an animal variable, make each of the animals shout.*/

package Prog2_poly;
class Animal{
	void shout(){
		System.out.println("shout");
	}
}
class Dog extends Animal{
	void shout(){
		System.out.println("Bark");
	}
}
class Horse extends Animal{
	void shout(){
		System.out.println("Neigh");
	}
}
class Cat extends Animal{
	void shout(){
		System.out.println("Meouw");
	}
}
public class polymorphism {
	public static void main(String[] args){
		Animal a=new Dog();
		System.out.print("Dog sound ");a.shout();
		a=new Horse();
		System.out.print("Horse sound ");a.shout();
		a=new Cat();
		System.out.print("Cat sound ");a.shout();
	}
}
