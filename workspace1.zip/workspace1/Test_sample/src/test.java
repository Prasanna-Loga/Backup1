import java.util.Scanner;

public class test {
	public static void main(String[] args){
//		Scanner in=new Scanner(System.in);
//		int input1=in.nextInt();
//		int[] input2=new int[input1];
//		int[] input3=new int[input1];
//		for(int i=0;i<input1;i++)
//			input2[i]=in.nextInt();   //lunch box type
//		for(int i=0;i<input1;i++)
//			input3[i]=in.nextInt();    //preferance
//		int lunch0=0,preferance0=0;
//		for(int i=0;i<input1;i++)
//			if(input2[i]==0) lunch0++;
//		for(int i=0;i<input1;i++)
//			if(input3[i]==0) preferance0++;
//	int count=0;
//	count +=Math.abs(preferance0-lunch0);
//	System.out.println(count);
	
	StringBuilder s=new StringBuilder("new");
	StringBuilder s1=new StringBuilder("new");
	String s2=new String("new");
	String s3=new String("new");
	System.out.println(s.equals(s1));
	System.out.println(s2.equals(s3));
	}
}
