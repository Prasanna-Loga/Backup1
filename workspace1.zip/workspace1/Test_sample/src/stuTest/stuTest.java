package stuTest;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class stuTest {
	public static void main(String[] args){
		
		TreeMap<Double,student> studentList=new TreeMap<Double,student>(Collections.reverseOrder());
		TreeMap<String,student> finalStudentList=new TreeMap<String,student>();
		Scanner in=new Scanner(System.in);
		Scanner in1=new Scanner(System.in);
		System.out.println("Enter number of student");
		int count=in.nextInt();
		for(int i=0;i<count;i++){
			student s=new student();
			System.out.println("Enter student name");
			s.setName(in1.nextLine());
			System.out.println("Enter M1");
			s.setM1(in.nextInt());
			System.out.println("Enter M2");
			s.setM2(in.nextInt());
			System.out.println("Enter M3");
			s.setM3(in.nextInt());
			System.out.println("Enter M4");
			s.setM4(in.nextInt());
			System.out.println("Enter M5");
			s.setM5(in.nextInt());
			s.setAvg((double)(s.getM1()+s.getM2()+s.getM3()+s.getM4()+s.getM5())/5.0);
			studentList.put(s.getAvg(),s);
		}
		//System.out.println(studentList);
		int rank=1;
		Set set = studentList.entrySet();
	    Iterator i = set.iterator();
	    while(i.hasNext()) {
	      Map.Entry me = (Map.Entry)i.next();
	      student s=new student();
	      
	      s=(student) me.getValue();
	      s.setRank(rank++);
	      System.out.println("Rank "+(s.getRank())+" "+s.getName()+" "+me.getKey());
	      finalStudentList.put(s.getName(), s);
	    }
	    System.out.println("Name\tMark1\tMark2\tMark3\tMark4\tMark5\tAvg\tRank");
	    Set finalSet = finalStudentList.entrySet();
	    Iterator j = finalSet.iterator();
	    while(j.hasNext()) {
	      Map.Entry me = (Map.Entry)j.next();
	      student s=new student();
	      s=(student) me.getValue();
	      
	      System.out.println(s.getName()+"\t"+s.getM1()+"\t"+s.getM2()+"\t"+s.getM3()+"\t"+s.getM4()+"\t"+s.getM5()+"\t"+s.getAvg()+"\t"+s.getRank());
	      }
	}

}
