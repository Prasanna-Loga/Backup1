package Prog_1;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class test1 {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		int[] a={5,4,3,5,2};
		int[] b=new int[5];
		int[] c=new int[5];
		int[] s=new int[5];
		int k=0;
		for(int i=0;i<5;i++){
		if(!(a[i]==1||a[i]==2||a[i]==4)){
			c[k++]=a[i];
		}
		}
		Arrays.sort(c,0,k);  
			  int l=0;
		for(int i=0;i<5;i++){
			if((a[i]==1||a[i]==2||a[i]==4)){
				b[l++]=a[i];
			}
			}
		Arrays.sort(b,0,l); 
	        int d=0;
	        for(int i=k-1;i>=0;i--){
	        	s[d++]=c[i];
	        }
	        for(int i=l-1;i>=0;i--){
	        	s[d++]=b[i];
	        }
	        System.out.printf("Modified arr[] : %s", 
                    Arrays.toString(s));
	}
}
