package Prog_1;

import java.lang.reflect.Method;

public class testClass {
 public static void main(String[] args) throws ClassNotFoundException{
	 Class c=Class.forName("java.lang.String");
	 Method[] m=c.getDeclaredMethods();
	 for(Method method:m)
		 System.out.println(method);
 }
}
