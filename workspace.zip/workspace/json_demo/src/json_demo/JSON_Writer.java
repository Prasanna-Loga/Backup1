package json_demo;
import java.io.FileWriter;
import java.util.LinkedHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JSON_Writer
{
    public static void main(String args[])
    {
        try
        {
            // Create a new JSONObject
            LinkedHashMap jsonObject = new LinkedHashMap();
            TreeMap<String,String> t=new TreeMap();
            // Add the values to the jsonObject
            jsonObject.put("Name", "Prasanna");
            jsonObject.put("Age", "25");
            jsonObject.put("ID", new Integer(377171));
            jsonObject.put("is_employee", new Boolean(true));

            // Create a new JSONArray object
            JSONArray jsonArray = new JSONArray();

            // Add values to the jsonArray
            jsonArray.add("C");
            jsonArray.add("CPP");
            jsonArray.add("JAVA");

            // Add the jsoArray to jsonObject
            jsonObject.put("LANGUAGE", jsonArray);

            JSONObject address = new JSONObject();
            address.put("FirstLine", "simmakal");
            address.put("secondLine", "Madurai");
            address.put("postcode", "625001");
        
            jsonObject.put("address", address);
            
                // Create a new FileWriter object
            FileWriter fileWriter = new FileWriter("C://Users/PR377171/sample1.json");

            // Writting the jsonObject into sample.json
            fileWriter.write(jsonObject.toString());
            fileWriter.close();

            System.out.println("JSON Object Successfully written to the file!!");

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}