import java.util.Scanner;


public class smpl1 {
public static void main(String[] args){
	String a="13,2453465";
	a=a.replace(',', '.');
	System.out.println(Double.parseDouble(a));
	
	

}
}
