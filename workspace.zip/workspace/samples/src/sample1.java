import java.util.Stack;


public class sample1 {
	public static void main(String[] args){
	
		System.out.println("welcome");
		String str="{([]){}()}";
		Stack s=new Stack();
		for(int i=0;i<str.length();i++){
			if(str.charAt(i)==')'||str.charAt(i)=='}'||str.charAt(i)==']')
			{
				System.out.println(i);
				System.out.println(s.peek()+"  "+str.charAt(i));
				if(s.peek().equals(new Character('{'))&&(str.charAt(i))=='}'){
					System.out.println("htd");s.pop();}
				else if(s.peek().equals(new Character('['))&&(str.charAt(i))==']')
					s.pop();
				else if(s.peek().equals(new Character('('))&&(str.charAt(i))==')')
					s.pop();
				
			}
			else
		s.push(new Character(str.charAt(i)));
		System.out.println(s);
		}
		System.out.println(s.isEmpty());
		if(s.isEmpty())
		System.out.println("bal");
		else
			System.out.println("not bal");
	}

}
