package Prog_1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Json {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		try {
			BufferedReader reader=new BufferedReader(new FileReader("C:\\Users\\PR377171\\Desktop\\train_inp.json"));
		String line = null;
		 JSONParser parser = new JSONParser();
		 Object obj=parser.parse(reader);
		//System.out.println(reader);
		  JSONArray array = (JSONArray)obj;
		  //System.out.println(array.size());
		  List<JSONArray> resumeList=new ArrayList<JSONArray>();   //List of resume
		  	for(Object i:array){
		  		resumeList.add(array);
		  	}
		  	JSONObject obj2 = null;
		// System.out.println(resumeList.size());
		 for(int i=0;i<resumeList.size();i++)
		{obj2 = (JSONObject)array.get(i);
		//System.out.println("asasasasas");
		  //System.out.println(obj2.get("text").toString());
		  String[] str=obj2.get("text").toString().split("\n");
		  for(int i1=0;i1<str.length;i1++){
			  if(str[i1].equals("EDUCATION"))
		  System.out.println("Degree "+str[i1+2]);
			  if(str[i1].contains("College")||str[i1].contains("University")||str[i1].contains("Institute")||str[i1].contains("School"))
				  System.out.println(str[i1]);
		  }
			System.out.println(str[0]);
			System.out.println();
		}
		
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}