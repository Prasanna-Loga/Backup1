
public class welcome {
	public static void main(String[] args){
		System.out.println("Welcome to Java Programming");
		System.out.println("Prasanna");
		StringBuffer builder = new StringBuffer();
		for(int num=0;num<3 ; num++) {
		    builder.append("String").append(num);
		}
		System.out.println(builder);
	}
}
