/*
 * 4.	Write an interface called Playable, with a method void play();
Let this interface be placed in a package called music.Write a class called Veena which implements Playable interface. Let this class be placed in a package music.string.Write a class called Saxophone which implements Playable interface. Let this class be placed in a package music.wind.Write another class Test in a package called live. Then,
a. Create an instance of Veena and call play() method
b. Create an instance of Saxophone and call play() method
c. Place the above instances in a variable of type Playable and then call play().

 */

package Prog4_Interface.live;

import Prog4_Interface.music.Playable;
import Prog4_Interface.music.string.Veena;
import Prog4_Interface.music.wind.Saxophone;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Sub class referrance  :");
		Veena veena=new Veena();
		veena.play();
		Saxophone sax=new Saxophone();
		sax.play();
		System.out.println();
		System.out.println("Interface referrance   :");
		Playable playing=new Veena();
		playing.play();
		playing =new Saxophone();
		playing.play();
	}

}
