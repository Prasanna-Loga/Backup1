package com.f.bankrecord;

import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

public class bankerDetail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file=new File("C:\\Users\\PR377171\\workspace1\\StreamsAssignments\\CustomerDetail.txt");
		
		
try(BufferedReader ls = Files.newBufferedReader(Paths.get(file.getPath()),Charset.defaultCharset())) {
			
	System.out.println(ls.lines().flatMap(line->Arrays.stream(line.split("\\s+"))).collect(Collectors.toList()));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
