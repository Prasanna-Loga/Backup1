package Prog_2;
//@FunctionalInterface
public interface Guitar {
//	public void p();

	default void play(){
	System.out.println("Playing Guitar........###...$$$$...###.......");
	}

}
