/*
 * . Task to find whether the Vector contain all List Elements (Objects) :
 */

package LinkedList;

import java.util.LinkedList;

public class MyPushPopOpr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> arrl = new LinkedList<String>();
		arrl.add("First");
		arrl.add("Second");
		arrl.add("Third");
		arrl.add("Random");
		System.out.println(arrl);
		System.out.println("\n After pushing Zero :");
		arrl.push("Zero");
		System.out.println(arrl);
		System.out.println("\n After poping :");
		arrl.pop();
		System.out.println(arrl);
	}

}
