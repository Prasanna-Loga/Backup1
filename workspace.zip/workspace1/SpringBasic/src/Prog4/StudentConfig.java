//package Prog4;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Scope;
//
//	@Configuration
//	public class StudentConfig {
//		@Bean
//		@Scope("prototype")
//		public Student student(){
//		return new Student();
//		}
//		@Bean
//		@Scope("singleton")
//		public StudentDetails details(){
//			return new StudentDetails();
//		}
//		@Bean
//		public logging log(){
//			return new logging();
//		}
//	}
