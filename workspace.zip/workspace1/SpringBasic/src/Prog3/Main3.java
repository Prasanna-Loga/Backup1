package Prog3;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main3 {
	public static void main(String[] args) {
		//using Annotation
		ApplicationContext ctx = new AnnotationConfigApplicationContext(playerConfig.class);
		Player player = null;
		System.out.println("----------------Player Details Entry-----------------------");
		Scanner input = new Scanner(System.in);
		Map<Player, String> m = new LinkedHashMap<Player, String>();
		System.out.println("Enter the number of Players");
		int count = input.nextInt();
		Country country = null;
		for (int i = 0; i < count; i++) {

			player = ctx.getBean(Player.class);

			System.out.println("Enter the player Id");
			player.setPlayerId(input.next());
			System.out.println("Enter the player name");
			player.setPlayerName(input.next());
			System.out.println("Enter the country of player:" + player.getPlayerName());
			String playerCountry = input.next();
			if (playerCountry.equalsIgnoreCase("INDIA")) {
				country = ctx.getBean(Country.class);
				country.setCountryId("C001");
			}
			if (playerCountry.equalsIgnoreCase("RSA")) {
				country = ctx.getBean(Country.class);
				country.setCountryId("C002");
			}
			country.setCountryName(playerCountry);
			player.setCountry(country);
			m.put(player, country.getCountryName());
		}
		System.out.println("------------------------------Player Detail list------------------------------");
		System.out.println("PLAYER_ID\tPLAYER_NAME\tCOUNTRY_ID\tCOUNTRY_NAME");
		System.out.println("--------------------------------------------------------------------");

		for (Map.Entry<Player, String> entry : m.entrySet())
			System.out.println(entry.getKey().getPlayerId() + "\t\t" + entry.getKey().getPlayerName() + "\t\t"
					+ entry.getKey().getCountry().getCountryId() + "\t\t"
					+ entry.getKey().getCountry().getCountryName());

		System.out.println("Enter the country");
		String check = input.next();
		System.out.println("Players from " + check + ":");
		for (Map.Entry<Player, String> entry : m.entrySet())
			if (entry.getValue().equalsIgnoreCase(check))
				System.out.println(entry.getKey().getPlayerName());
	}
}
