package Prog3;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class playerConfig {
	@Bean
	@Scope("prototype")
	public Player player(){
	return new Player();
	}
	@Bean
	@Scope("prototype")
	public Country country(){
		return new Country();
	}
}
